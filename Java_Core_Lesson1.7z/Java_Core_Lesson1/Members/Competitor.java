package Java_Core_Lesson1.Members;

public interface Competitor {
    void run(int dist);
    void jump(int dist);
    boolean isOnDistance();
    void  info();
}
