package Java_Core_Lesson1;

import Java_Core_Lesson1.Members.Cat;
import Java_Core_Lesson1.Members.Competitor;
import Java_Core_Lesson1.Members.Human;
import Java_Core_Lesson1.Members.Robot;
import Java_Core_Lesson1.Sport_Tests.Obstacle;
import Java_Core_Lesson1.Sport_Tests.Track;
import Java_Core_Lesson1.Sport_Tests.Wall;

public class MainTest {

    static int count = 5;
    static int runMax = 300; //максимальная длина дорожки
    static int jumpMax = 30; //максимальная высота стены

    public static void main(String[] args){
        //генерируем массив участников
        Competitor[] competitors = new Competitor[count];
        for (int i = 0; i < count; i++){
            if (i % 2 == 0) {competitors[i] = new Human("Human" + i, (int) (Math.random() * (runMax*2)), (int) (Math.random() * (jumpMax*2)));}
            else if (i % 3 == 0) {competitors[i] = new Robot("Robot" + i, (int) (Math.random() * (runMax*2)), (int) (Math.random() * (jumpMax*2)));}
            else {competitors[i] = new Cat("Cat" + i, (int) (Math.random() * (runMax*2)), (int) (Math.random() * (jumpMax*2)));}
        }
        //генерируем массив препятствий
        Obstacle[] obstacles = new Obstacle[count];
        for (int i = 0; i < count; i++){
            obstacles[i] =  (i % 2 == 0) ? new Track((int) (Math.random() * runMax)) : new Wall((int) (Math.random() * jumpMax));
        }

        Course courses = new Course(obstacles);
        Team team = new Team(competitors);
        courses.runTournament(team);
    }
}
