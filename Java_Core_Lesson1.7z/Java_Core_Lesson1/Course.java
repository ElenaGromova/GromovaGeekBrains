package Java_Core_Lesson1;

import Java_Core_Lesson1.Members.Competitor;
import Java_Core_Lesson1.Sport_Tests.Obstacle;

public class Course {
    Obstacle[] obstacles;

    public Course(Obstacle[] obstacles){
        this.obstacles = obstacles;
    }

    public void runTournament(Team team){
       for (Competitor t: team.competitors){
            for (Obstacle c: this.obstacles){
                c.doIt(t);
                if (!t.isOnDistance()) break;
            }
        }

        for (Competitor t: team.competitors){
            t.info();
        }
    }
}
