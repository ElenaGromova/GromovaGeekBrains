package Java_Core_Lesson1;

import Java_Core_Lesson1.Members.Competitor;

public class Team {
    Competitor[] competitors;

    public Team(Competitor[] competitors){
        this.competitors = competitors;
    }
}
