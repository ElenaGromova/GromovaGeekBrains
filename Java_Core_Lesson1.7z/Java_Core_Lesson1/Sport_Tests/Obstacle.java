package Java_Core_Lesson1.Sport_Tests;

import Java_Core_Lesson1.Members.Competitor;

public abstract class Obstacle{

    public abstract void doIt(Competitor competitor);
}
